# BPA Onboarding Patch (A+B+C)

এই patch আপনার existing **BPA backend API** তে নতুন **Owner Panel + Admin Panel onboarding workflow** যোগ করার জন্য।
Flutter‑এর সাথে যেসব পুরোনো API already connected, সেগুলো না বদলে নতুন namespace যোগ করবে:

- Locations: `/api/v1/locations`
- Owner: `/api/v1/owner`
- Admin: `/api/v1/admin`

## Included Files
### (A) Prisma migrate safe strategy
- `docs/prisma_migrate_safe_strategy.md`

### (B) Seed scripts (DNCC/DSCC + Areas)
- `prisma/seeders/seedLocationsDhaka.js` (DNCC/DSCC + sample areas)
- `prisma/seed.js` (optional runner; ব্যবহার না করতে চাইলে শুধু seeder ফাইল কপি করুন)

### (C) Express routes/controllers (copy‑paste ready skeleton)
- `src/api/v1/modules/locations/*`
- `src/api/v1/modules/owner/*`
- `src/api/v1/modules/admin/*`
- `src/api/v1/modules/audit/*`
- `src/middlewares/auth.js` (placeholder)
- `src/middlewares/roleGuard.js`
- `src/middlewares/auditWriter.js`

## How to apply (quick)
1) Patch files আপনার backend repo‑তে merge/copy করুন (paths match করে)।
2) `prisma/schema.prisma` এ (আগের মেসেজে দেওয়া) Location + Org + Branch + Verification + AuditLog models যোগ করুন।
3) Migrate:
   - dev: `npx prisma migrate dev --create-only --name onboarding_phase1` তারপর migration review করে `npx prisma migrate dev`
4) Seed:
   - `node prisma/seed.js` (অথবা আপনার existing seed runner‑এ `seedLocationsDhaka` call করুন)
5) Routes register:
   - `app.use('/api/v1/locations', locationsRoutes)`
   - `app.use('/api/v1/owner', ownerRoutes)`
   - `app.use('/api/v1/admin', adminRoutes)`

## Notes
- Controllers এ validation minimal রাখা হয়েছে—আপনার production rules অনুযায়ী tighten করবেন।
- `req.user = { id, role }` ধরে নেওয়া হয়েছে (আপনার existing auth middleware অনুযায়ী adjust করুন)।
