// Single stable entrypoint for BPA API
// - Loads env
// - Uses the hardened Express app (src/app.js)

require('dotenv').config();

const app = require('./app');

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  // Keep log format stable (used in Docker logs)
  console.log(`🚀 Server running at http://0.0.0.0:${port}${process.env.API_PREFIX || '/api/v1'}`);
});
