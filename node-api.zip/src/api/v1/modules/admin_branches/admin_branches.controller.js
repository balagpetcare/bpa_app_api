const prisma = require("../../../../infrastructure/db/prismaClient");

function toInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

// GET /api/v1/admin/branches
exports.list = async (req, res) => {
  const status = req.query?.status ? String(req.query.status).trim() : "";
  const orgId = toInt(req.query?.orgId);
  const q = req.query?.q ? String(req.query.q).trim() : "";

  const where = {};
  if (status) where.status = status;
  if (orgId) where.orgId = orgId;
  if (q) {
    where.OR = [{ name: { contains: q, mode: "insensitive" } }];
  }

  const rows = await prisma.branch.findMany({
    where,
    orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
    select: {
      id: true,
      orgId: true,
      name: true,
      status: true,
      verificationStatus: true,
      createdAt: true,
      updatedAt: true,
      org: { select: { id: true, name: true, ownerUserId: true, status: true } },
      typeLinks: {
        select: {
          isPrimary: true,
          branchType: { select: { id: true, code: true, nameEn: true, nameBn: true } },
        },
      },
    },
    take: 300,
  });

  return res.json({ success: true, data: rows });
};

// POST /api/v1/admin/branches
exports.create = async (req, res) => {
  const orgId = toInt(req.body?.orgId);
  const name = req.body?.name ? String(req.body.name).trim() : "";
  const status = req.body?.status ? String(req.body.status).trim() : undefined;
  const verificationStatus = req.body?.verificationStatus ? String(req.body.verificationStatus).trim() : undefined;
  const addressJson = req.body?.addressJson ?? null;
  const capabilitiesJson = req.body?.capabilitiesJson ?? {};
  const featuresJson = req.body?.featuresJson ?? {};
  const typeCodes = Array.isArray(req.body?.typeCodes) ? req.body.typeCodes.map((x) => String(x || "").trim()).filter(Boolean) : [];

  if (!orgId) return res.status(400).json({ success: false, message: "orgId is required" });
  if (!name) return res.status(400).json({ success: false, message: "name is required" });

  const branch = await prisma.branch.create({
    data: {
      orgId,
      name,
      ...(status ? { status } : {}),
      ...(verificationStatus ? { verificationStatus } : {}),
      addressJson,
      capabilitiesJson,
      featuresJson,
    },
  });

  if (typeCodes.length) {
    const types = await prisma.branchType.findMany({ where: { code: { in: typeCodes } }, select: { id: true, code: true } });
    if (types.length) {
      await prisma.branchTypeOnBranch.createMany({
        data: types.map((t, idx) => ({ branchId: branch.id, branchTypeId: t.id, isPrimary: idx === 0 })),
        skipDuplicates: true,
      });
    }
  }

  const row = await prisma.branch.findUnique({
    where: { id: branch.id },
    include: { typeLinks: { include: { branchType: true } }, org: true },
  });

  return res.status(201).json({ success: true, data: row });
};

// GET /api/v1/admin/branches/:id
exports.getById = async (req, res) => {
  const id = toInt(req.params?.id);
  if (!id) return res.status(400).json({ success: false, message: "Invalid id" });

  const row = await prisma.branch.findUnique({
    where: { id },
    include: {
      org: true,
      typeLinks: { include: { branchType: true } },
      profileDetails: { include: { documents: { include: { media: true } } } },
      publishRequests: { orderBy: { id: "desc" } },
    },
  });
  if (!row) return res.status(404).json({ success: false, message: "Not found" });

  return res.json({ success: true, data: row });
};

// PATCH /api/v1/admin/branches/:id
exports.updateById = async (req, res) => {
  const id = toInt(req.params?.id);
  if (!id) return res.status(400).json({ success: false, message: "Invalid id" });

  const data = {};
  if (req.body?.name !== undefined) data.name = String(req.body.name || "").trim();
  // status is BranchStatus enum: DRAFT | PENDING_REVIEW | ACTIVE | INACTIVE | BLOCKED
  // Some older UIs used APPROVED/REJECTED. Map them safely.
  if (req.body?.status !== undefined) {
    const incoming = String(req.body.status || "").toUpperCase().trim();
    const mapped = incoming === "APPROVED" ? "ACTIVE" : incoming === "REJECTED" ? "BLOCKED" : incoming;
    const allowed = new Set(["DRAFT", "PENDING_REVIEW", "ACTIVE", "INACTIVE", "BLOCKED"]);
    if (mapped && !allowed.has(mapped)) {
      return res.status(400).json({ success: false, message: `Invalid status: ${incoming}` });
    }
    data.status = mapped;
  }
  if (req.body?.verificationStatus !== undefined) data.verificationStatus = String(req.body.verificationStatus).trim();
  if (req.body?.addressJson !== undefined) data.addressJson = req.body.addressJson;
  if (req.body?.capabilitiesJson !== undefined) data.capabilitiesJson = req.body.capabilitiesJson;
  if (req.body?.featuresJson !== undefined) data.featuresJson = req.body.featuresJson;
  if (data.name === "") return res.status(400).json({ success: false, message: "name cannot be empty" });

  await prisma.branch.update({ where: { id }, data });

  // Optional: update types by codes (replace all)
  if (Array.isArray(req.body?.typeCodes)) {
    const typeCodes = req.body.typeCodes.map((x) => String(x || "").trim()).filter(Boolean);
    await prisma.branchTypeOnBranch.deleteMany({ where: { branchId: id } });
    if (typeCodes.length) {
      const types = await prisma.branchType.findMany({ where: { code: { in: typeCodes } }, select: { id: true, code: true } });
      await prisma.branchTypeOnBranch.createMany({
        data: types.map((t, idx) => ({ branchId: id, branchTypeId: t.id, isPrimary: idx === 0 })),
        skipDuplicates: true,
      });
    }
  }

  const row = await prisma.branch.findUnique({
    where: { id },
    include: { org: true, typeLinks: { include: { branchType: true } } },
  });

  return res.json({ success: true, data: row });
};
