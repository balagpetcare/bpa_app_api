const prisma = require("../../../../infrastructure/db/prismaClient");

function toInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

// GET /api/v1/admin/organizations
exports.list = async (req, res) => {
  const status = req.query?.status ? String(req.query.status).trim() : "";
  const q = req.query?.q ? String(req.query.q).trim() : "";
  const ownerUserId = toInt(req.query?.ownerUserId);

  const where = {};
  if (status) where.status = status;
  if (ownerUserId) where.ownerUserId = ownerUserId;
  if (q) {
    where.OR = [
      { name: { contains: q, mode: "insensitive" } },
      { supportPhone: { contains: q, mode: "insensitive" } },
    ];
  }

  const rows = await prisma.organization.findMany({
    where,
    orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
    select: {
      id: true,
      ownerUserId: true,
      status: true,
      name: true,
      supportPhone: true,
      createdAt: true,
      updatedAt: true,
      _count: { select: { branches: true } },
    },
    take: 200,
  });

  return res.json({ success: true, data: rows });
};

// POST /api/v1/admin/organizations
exports.create = async (req, res) => {
  const ownerUserId = toInt(req.body?.ownerUserId);
  const name = req.body?.name ? String(req.body.name).trim() : "";
  const supportPhone = req.body?.supportPhone ? String(req.body.supportPhone).trim() : null;
  const addressJson = req.body?.addressJson ?? null;
  const status = req.body?.status ? String(req.body.status).trim() : undefined;

  if (!ownerUserId) return res.status(400).json({ success: false, message: "ownerUserId is required" });
  if (!name) return res.status(400).json({ success: false, message: "name is required" });

  const row = await prisma.organization.create({
    data: {
      ownerUserId,
      name,
      supportPhone,
      addressJson,
      ...(status ? { status } : {}),
    },
  });

  return res.status(201).json({ success: true, data: row });
};

// GET /api/v1/admin/organizations/:id
exports.getById = async (req, res) => {
  const id = toInt(req.params?.id);
  if (!id) return res.status(400).json({ success: false, message: "Invalid id" });

  const row = await prisma.organization.findUnique({
    where: { id },
    include: {
      branches: {
        orderBy: { id: "desc" },
        select: { id: true, name: true, status: true, verificationStatus: true, createdAt: true },
      },
      legalProfile: true,
    },
  });

  if (!row) return res.status(404).json({ success: false, message: "Not found" });
  return res.json({ success: true, data: row });
};

// PATCH /api/v1/admin/organizations/:id
exports.updateById = async (req, res) => {
  const id = toInt(req.params?.id);
  if (!id) return res.status(400).json({ success: false, message: "Invalid id" });

  const data = {};
  if (req.body?.name !== undefined) data.name = String(req.body.name || "").trim();
  if (req.body?.supportPhone !== undefined)
    data.supportPhone = req.body.supportPhone ? String(req.body.supportPhone).trim() : null;
  if (req.body?.addressJson !== undefined) data.addressJson = req.body.addressJson;
  if (req.body?.status !== undefined) data.status = String(req.body.status).trim();

  if (data.name === "") return res.status(400).json({ success: false, message: "name cannot be empty" });

  const row = await prisma.organization.update({ where: { id }, data });
  return res.json({ success: true, data: row });
};
