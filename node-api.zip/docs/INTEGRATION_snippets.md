# Integration snippets (copy-paste)

## 1) server.js routes
In your API router (example):

```js
const locationsRoutes = require('./api/v1/modules/locations/locations.routes');
const ownerRoutes = require('./api/v1/modules/owner/owner.routes');
const adminRoutes = require('./api/v1/modules/admin/admin.routes');
const auditRoutes = require('./api/v1/modules/audit/audit.routes');

app.use('/api/v1/locations', locationsRoutes);
app.use('/api/v1/owner', ownerRoutes);
app.use('/api/v1/admin', adminRoutes);
app.use('/api/v1/admin/audit', auditRoutes);
```

## 2) req.user injection
আপনার existing auth যেভাবে কাজ করে সেটা 그대로 রাখুন।
এই patch এ assume করা হয়েছে:
```js
req.user = { id: '...', role: 'OWNER'|'ADMIN'|'SUPER_ADMIN' };
```

