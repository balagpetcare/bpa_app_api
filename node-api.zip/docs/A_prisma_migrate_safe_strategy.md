# (A) Prisma migrate safe strategy (Safe + Professional)

> লক্ষ্য: Existing Flutter-connected API/DB যেন না ভাঙে।

## 1) Local Dev (Safe workflow)
1. **Schema update করুন** (`prisma/schema.prisma`) — নতুন model/field যোগ করুন।
2. **Create-only migration বানান** (কোনও destructive change থাকলে আগে ধরার জন্য):
   ```bash
   npx prisma migrate dev --name onboarding_location_phase --create-only
   ```
3. তৈরি হওয়া migration folder খুলে SQL দেখুন:
   - DROP COLUMN / DROP TABLE / ALTER TYPE (data loss) আছে কিনা দেখুন
   - risky হলে SQL ম্যানুয়ালি edit করুন অথবা আলাদা step নিন
4. তারপর apply করুন:
   ```bash
   npx prisma migrate dev
   ```
5. Seed চালান:
   ```bash
   node prisma/seed.js
   ```

## 2) Destructive change হলে (Production-grade approach)
- Required field / enum type change / column type change এর মতো জায়গায় Prisma অনেক সময় drop-recreate চায়।
- Safe pattern:
  1) নতুন nullable field add
  2) data backfill script
  3) field কে required করা

## 3) Production
- Production এ **never** `migrate dev` ব্যবহার করবেন না।
- ব্যবহার করবেন:
  ```bash
  npx prisma migrate deploy
  ```
- Seed optional (controlled):
  ```bash
  node prisma/seed.js
  ```

## 4) Shadow DB errors (P3006) এ করণীয়
- আগের broken migration থাকলে:
  - `prisma migrate resolve --rolled-back <migration>`
  - schema vs database sync করুন
- Dev এ absolute last resort (data lose):
  ```bash
  npx prisma migrate reset
  ```

