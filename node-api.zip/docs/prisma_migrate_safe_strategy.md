# (A) Prisma migrate safe strategy (BPA)

এই স্ট্র্যাটেজি আপনার **data loss** এড়াতে এবং production-ready ভাবে migrate করার জন্য।

## 1) Dev environment (safe workflow)
1. `git status` clean রাখুন
2. Prisma schema changes করুন (enums/models/indexes)
3. **Create-only migration** করুন:
   ```bash
   npx prisma migrate dev --create-only --name onboarding_locations_workflow
   ```
4. `prisma/migrations/<timestamp>_onboarding_locations_workflow/migration.sql` খুলে দেখুন:
   - `DROP COLUMN`, `DROP TABLE`, `ALTER COLUMN TYPE` (data casting ছাড়া) থাকলে সতর্ক
   - Required column add করলে default/nullable strategy ঠিক করুন

5. Safe edits rules
- Existing table এ required field add করলে:
  - প্রথমে nullable রাখুন
  - data backfill করুন
  - তারপর required করুন

- Enum/code type change (যেমন string → enum):
  - **Stepwise**: নতুন enum column add → data copy/mapping → old column drop

6. Apply migration
   ```bash
   npx prisma migrate dev
   ```

## 2) Production environment (recommended)
1. Production এ `migrate dev` ব্যবহার করবেন না
2. Migration repo তে commit
3. Deploy এ run:
   ```bash
   npx prisma migrate deploy
   ```

## 3) Shadow DB issues (P3006) avoid
- Migration fail করলে:
  - `npx prisma migrate dev --create-only` → SQL manual fix
  - `npx prisma migrate resolve --rolled-back <migration_name>` (যদি partial state)

## 4) Index + Unique strategy
- Search endpoint fast রাখতে:
  - `Area(cityCorporationId)` index
  - `Area(parentId)` index
  - Optional: `Area(nameEn)` index if needed

## 5) Minimal acceptance test
- `npx prisma generate`
- `npx prisma migrate dev`
- `node prisma/seed.js`
- API start, and:
  - `GET /api/v1/locations/city-corporations`
  - `GET /api/v1/locations/areas?corp=DNCC&q=banasree`
